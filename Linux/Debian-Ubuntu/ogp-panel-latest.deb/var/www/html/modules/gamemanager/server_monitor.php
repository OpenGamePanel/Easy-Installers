<link rel="stylesheet" href="js/jquery/ui/themes/base/jquery.ui.all.css">
<script type="text/javascript" src="js/jquery/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="js/jquery/ui/jquery-ui-1.10.4.min.js"></script>
<script type="text/javascript" src="js/jquery/plugins/jquery.tablesorter.collapsible.js"></script>
<script type="text/javascript" src="js/jquery/plugins/jquery.tablesorter.mod.js"></script>
<script type="text/javascript" src="js/jquery/plugins/jquery.quicksearch.js"></script>
<script type="text/javascript" src="js/modules/gamemanager.js"></script>
<?php
/*
 *
 * OGP - Open Game Panel
 * Copyright (C) Copyright (C) 2008 - 2013 The OGP Development Team
 *
 * http://www.opengamepanel.org/
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

require_once('modules/gamemanager/home_handling_functions.php');
require_once("modules/config_games/server_config_parser.php");

require_once("includes/refreshed.php");
require_once('includes/lib_remote.php');

function renderParam($param, $last_param, $param_access_enabled, $home_id)
{
	global $db;
	$attributesString = "";
	foreach ($param->attribute as $attribute)
		$attributesString .= $attribute['key']. "='$attribute' ";

	$disabledString = ($param_access_enabled) ? "" : "disabled ";
	
	if (array_key_exists((string)$param['key'], $last_param))
		$paramValue = (string)$last_param[(string)$param['key']];
	else
		$paramValue = (string)$param->default;

	$idString = "id='".clean_id_string($param['key'])."'";
	$nameString = "name='params[".$param['key']."]'";
	$paramType = $param['type'];
	if ($paramType == "select")
	{
		$inputElementString = "<select $idString $nameString $disabledString>";
		foreach ($param->option as $option)
		{
			$optionValue = (string)($option['value']);
			$selectedString = ($optionValue == $paramValue) ? "selected='selected'" : "";
			$valueString = "value=\"".str_replace('"', "&quot;", strip_real_escape_string($optionValue))."\"";
			$inputElementString .= "<option $selectedString $valueString>$option</option>";
		}
		$inputElementString .="</select>";
	} else
		{
			if ($paramType == "checkbox_key_value") {
				if ($paramValue) // convert the XML object to string
					$attributesString .= "checked='checked' ";
				$paramValue = $param['key'];
				$paramType = "checkbox";
			} 
			else if ($paramType == "checkbox")
			{
				if ($paramValue) // convert the XML object to string
					$attributesString .= "checked='checked' ";
			}
			$inputElementString = "<input $idString $nameString ".
				"type='$paramType' value=\"".str_replace('"', "&quot;", strip_real_escape_string($paramValue))."\" ".
				"$disabledString $attributesString/>";
		}

	echo "<tr><td class='right'><label for='".clean_id_string($param['key'])."'>".$param['key'].
		":</label></td><td class='left'>$inputElementString<label for='".clean_id_string($param['key'])."'>";

	if ( !empty($param->caption) )
		echo $param->caption;
	if ( !empty($param->desc) )
		echo "<br/><span class='info'>(".$param->desc.")</span>";

	echo "</label></td></tr>\n";
}

function get_sync_name($server_xml)
{
	if( $server_xml->lgsl_query_name )
	{
		$sync_name = $server_xml->lgsl_query_name;
		if($sync_name == "quake3")
		{
			if($server_xml->game_name == "Quake 3")
				$sync_name = "q3";
		}
	}
	elseif( $server_xml->gameq_query_name )
	{
		$sync_name = $server_xml->gameq_query_name;
		if($sync_name == "minecraft")
		{
			if($server_xml->game_name == "Minecraft Tekkit")
				$sync_name = "tekkit";
			elseif($server_xml->game_name == "Minecraft Bukkit")
				$sync_name = "bukkit";
		}
	}
	elseif( isset($server_xml->protocol) )
		$sync_name = $server_xml->protocol;
	else
		$sync_name = $server_xml->mods->mod['key'];
	return $sync_name;
}

function exec_ogp_module() {
	global $db, $settings;
	echo "<h2>". game_monitor ."</h2>";
	$refresh = new refreshed();
	set_time_limit(0);
	$stats_servers_online = 0;
	$stats_servers = 0;
	$stats_players = 0;
	$stats_maxplayers = 0;

	$isAdmin = $db->isAdmin( $_SESSION['user_id'] );
	if ( $isAdmin )
		$server_homes = $db->getHomesFor('admin', $_SESSION['user_id']);
	else
		$server_homes = $db->getHomesFor('user_and_group', $_SESSION['user_id']);

	if( $server_homes === FALSE )
	{
		// If there are no games, then there can not be any mods either.
		print_failure( no_game_homes_assigned );
		if ( $isAdmin )
		{
			echo "<p><a href='?m=user_games&amp;p=assign&amp;user_id=$_SESSION[user_id]'>".
				 assign_game_homes ."</a></p>";
		}
		return;
	}
	
	foreach($_POST as $key => $value)
	{
		if( preg_match( "/^action/", $key ) )
		{
			list($action,$home_id,$mod_id,$ip,$port) = explode("-", $value);
			exec_operation( $action, $home_id, $mod_id, $ip, $port );
		}
	}
	
	if ( empty( $_GET['home_id-mod_id-ip-port'] ) )
		unset( $_GET['home_id-mod_id-ip-port'] );
	if ( empty( $_GET['home_id'] ) )
		unset( $_GET['home_id'] );
	if ( isset($_GET['home_cfg_id']) and $_GET['home_cfg_id'] ==  game_type  )
		unset( $_GET['home_cfg_id'] );

	create_home_selector_game_type($_GET['m'], $_GET['p'], $server_homes);

	if (!isset($_GET['home_id-mod_id-ip-port']) and !isset($_GET['home_id']) and !isset($_GET['home_cfg_id'])) 
	{
		create_home_selector_address($_GET['m'], $_GET['p'], $server_homes);
		$show_all = TRUE;
	}
	else
	{
		create_home_selector_address($_GET['m'], $_GET['p'], $server_homes);
		create_home_selector($_GET['m'], $_GET['p'], "show_all");
		$show_all = FALSE;
	}

	require("protocol/lgsl/lgsl_protocol.php");
	?>
		<form>
			<b><?php print_lang('search'); ?>:</b>
			<input type="text" id="search">
		</form>
	<?php
	$info = $db->getUserById($_SESSION['user_id']);
	if($info['user_expires'] != "X")
	{
	?>
		<span style="color:black;font-weight:bold;">
			<center>
			<?php echo print_lang('account_expiration'); ?>: <span style="color:green;"><?php echo date( "l, F jS, Y, H:i:s", $info['user_expires'] ).
			" ( ".str_replace('hr', 'hours', read_expire($info['user_expires'])).")"; ?></span>
			</center>
		</span>
	<?php
	}

	echo "<table id='servermonitor' class='tablesorter'>".
		 "<thead>".
		 "<tr>".
		 "\t<th style='width:16px;background-position: center;'></th>".
		 "\t<th style='width:16px;background-position: center;'></th>".
		 "\t<th>" . server_name . "</th>".
		 "\t<th>" . address . "</th>".
		 "\t<th>" . owner . "</th>".
		 "\t<th>".
		 "\t\t" . operations . "".
		 "\t\t<img style='border:0;height:15px;' id='action-stop' src='" . check_theme_image("images/stop.png") . "'/>".
		 "\t\t<img style='border:0;height:15px;' id='action-restart' src='" . check_theme_image("images/restart.png") . "'/>".
		 "\t\t<img style='border:0;height:15px;' id='action-start' src='" . check_theme_image("images/start.png") . "'/>".
		 "\t</th>".
		 "</tr>".
		 "</thead>".
		 "<tbody>";

	$litefm_installed = $db->isModuleInstalled('litefm');
	$ftp_installed = $db->isModuleInstalled('ftp');
	$addonsmanager_installed = $db->isModuleInstalled('addonsmanager');
	$mysql_installed = $db->isModuleInstalled('mysql');
	if( isset( $_GET['home_id-mod_id-ip-port']) )
		list( $post_home_id,
			  $post_mod_id, 
			  $post_ip, 
			  $post_port ) = explode( "-", $_GET['home_id-mod_id-ip-port'] );
	foreach( $server_homes as $server_home )
	{
		if( ( $show_all or isset($_GET['home_cfg_id']) ) AND ( !isset($server_home['ip']) or !isset($server_home['mod_id']) ) )
			continue;
		// Count the number of servers.
		$stats_servers++;
		
		if( $show_all 
			OR ( isset( $_GET['home_id'] ) and $_GET['home_id'] == $server_home['home_id'] ) 
			OR ( isset( $_GET['home_id-mod_id-ip-port'] ) and $server_home['home_id'] == $post_home_id and $server_home['mod_id'] == $post_mod_id and $post_ip == $server_home['ip'] and $post_port == $server_home['port'] ) 
			OR ( isset( $_GET['home_cfg_id'] ) and $_GET['home_cfg_id'] == $server_home['home_cfg_id'] ) 
		  )
		{
			//Unset variables.
			unset($map,
				  $trclass, 
				  $first, 
				  $second, 
				  $onlineT, 
				  $ts3opt, 
				  $offlineT, 
				  $halfT, 
				  $ministart, 
				  $player_list, 
				  $groupsus, 
				  $name,
				  $mod_name,
				  $SrvCtrl,
				  $lite_fm,
				  $manager,
				  $user,
				  $pos,
				  $ftp,
				  $addonsmanager,
				  $ctrlChkBoxes);
			
			if ( $isAdmin )
			{
				$server_home['access_rights'] = "ufpetc";
			}
			if ($server_home['mod_name'] == "none" OR $server_home['mod_name'] == "None")
				$mod_name = "";
			elseif($server_home['mod_name'] != $server_home['game_name'])
				$mod_name = " ( ".$server_home['mod_name']." )";
						
			$get_size = "<table align='left' class='monitorbutton' ><tr>".
						"<td align='middle' class='size' data-home_id='".$server_home["home_id"]."'>".
						"<img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/file_size.png") . "' title='".
						 get_size ."'/>\n<br /><span style='font-weight:bold;'>". get_size ."</span></td></tr></table>";
						
			$manager = "<a href='?m=user_games&amp;p=edit&amp;home_id=".$server_home['home_id']."'>\n".
						"<table align='left' class='monitorbutton' ><tr><td align='middle' >".
						"<img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/edit.png") . "' title='".
						 edit ."'/>\n<br />". edit ."\n</td></tr></table></a>";
						

			// Only show the filemanager link when the litefm is installed.
			if ( preg_match("/f/",$server_home['access_rights']) > 0 && $litefm_installed )
			{
				$lite_fm  = "<a href='?m=litefm&amp;home_id=".$server_home['home_id']."'>\n".
							"<table align='left' class='monitorbutton' ><tr><td align='middle' >".
							"<img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/txt.png") . "' title='".
							 file_manager ."'/>\n<br />". file_manager ."\n</td></tr></table></a>";
			}
			
			if ( preg_match("/t/",$server_home['access_rights']) > 0 && $ftp_installed )
			{
				$ftp = "<a href='?m=ftp&amp;home_id=".$server_home['home_id']."'>\n".
						"<table align='left' class='monitorbutton' ><tr><td align='middle' >".
						"<img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/ftp.png") . "' title='".
						 ftp ."'/>\n<br>". ftp ."\n</td></tr></table></a>";
			}
			if ( $addonsmanager_installed )
			{
				$addons = $db->resultQuery("SELECT DISTINCT addon_id FROM OGP_DB_PREFIXaddons NATURAL JOIN OGP_DB_PREFIXconfig_homes WHERE home_cfg_id=".$server_home['home_cfg_id']);
				$addons_qty = count($addons);
				if($addons and $addons_qty >= 1){
					$addonsmanager = "<a href='?m=addonsmanager&amp;p=user_addons&amp;home_id=".
									 $server_home['home_id']."&amp;mod_id=".$server_home['mod_id'].
									 "&amp;ip=".$server_home['ip']."&amp;port=".$server_home['port']."'>\n".
									 "<table align='left' class='monitorbutton' ><tr><td align='middle' >".
									 "<img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("modules/administration/images/addons_manager.png") . "' title='".
									  addons ."'/>\n<br />". addons ."\n<b style='font-size:0.9em' >(".
									 $addons_qty.")</td></tr></table></a>";
				}
			}
			
			if ( $mysql_installed )
			{
				$mysql_dbs = $db->resultQuery("SELECT db_id FROM OGP_DB_PREFIXmysql_databases WHERE enabled=1 AND home_id=".$server_home['home_id']);

				if(!empty($mysql_dbs))
					$mysql = "<a href='?m=mysql&p=user_db&home_id=".$server_home['home_id']."'>\n".
							 "<table align='left' class='monitorbutton' ><tr><td align='middle' >".
							 "<img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("modules/administration/images/mysql_admin.png") . "' title='".
							  mysql_databases ."'/>\n<br />". mysql_databases ."\n</td></tr></table></a>\n";
			}

			if( !isset($server_home['mod_id']) )
			{
				$ministart = fail_no_mods;

				if ( $isAdmin )
				{
					$ministart .= "<a href='?m=user_games&amp;p=edit&amp;home_id=".$server_home['home_id']."'>" . configure_mods . "</a>";
				}
			}

			$server_xml = read_server_config(SERVER_CONFIG_LOCATION."/".$server_home['home_cfg_file']);
			
			if ( $server_xml )
			{
				if (preg_match("/u/",$server_home['access_rights']))
				{
					$master_server_home_id = $db->getMasterServer( $server_home['remote_server_id'], $server_home['home_cfg_id'] );
					if ( $master_server_home_id != FALSE )
					{
						if ( !$db->getGameHomeWithoutMods($master_server_home_id) )
						{
							$db->setMasterServer("remove", $master_server_home_id, $server_home['home_cfg_id'], $server_home['remote_server_id']);
							$master_server_home_id = FALSE;
						}
					}
					// In case game is compatible with steam we offer a way to use steam with the updates.
					if( $server_xml->installer == "steamcmd" )
					{						
						if( $master_server_home_id != FALSE AND $master_server_home_id != $server_home['home_id']  )
						{
							$manager .= "<form name='steam_master_".$server_home['home_id']."_".$server_home['mod_id'].
										"_".str_replace(".","",$server_home['ip'])."_".$server_home['port']."' action='?m=gamemanager&amp;p=update&amp;home_id=".
										$server_home['home_id']."&amp;mod_id=".$server_home['mod_id']."&amp;update=update' method='POST' >\n".
										"<table align='left' class='monitorbutton' >\n".
										"<tr><td align='middle' onclick='document.steam_master_".$server_home['home_id']."_".
										$server_home['mod_id']."_".str_replace(".","",$server_home['ip'])."_".$server_home['port'].
										".submit()' ><img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/master.png") . "' />".
										"<br /><span style='font-weight:bold;'>". update_from_local_master_server .
										"</span><input id='master".$server_home['home_id'].
										"' type='hidden' name='master_server_home_id' value='".$master_server_home_id.
										"' /></td></tr>\n</table>\n</form>";
						}
						$manager .= "<form name='steam_".$server_home['home_id']."_".$server_home['mod_id']."_".
									str_replace(".","",$server_home['ip'])."_".$server_home['port']."' action='?m=gamemanager&amp;p=update&amp;home_id=".
									$server_home['home_id']."&amp;mod_id=".$server_home['mod_id']."&amp;update=update' method='POST' >\n".
									"<table align='left' class='monitorbutton' >\n".
									"<tr><td align='middle' onclick='document.steam_".$server_home['home_id']."_".$server_home['mod_id']."_".str_replace(".","",$server_home['ip']).
									"_".$server_home['port'].".submit()' ><img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/steam.png") . "' />".
									"<br /><span style='font-weight:bold;'>". install_update_steam .
									"</span></td></tr>\n</table>\n</form>";
					}
					// In other cases manual update is provided.
					else
					{
						$manager .= "<a href='?m=gamemanager&amp;p=update_manual&amp;home_id=".$server_home['home_id'].
									"&amp;mod_id=".$server_home['mod_id']."&amp;update=update'>\n".
									"<table align='left' class='monitorbutton' ><tr><td align='middle' >".
									"<img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/install.png") . "' title='".
									 install_update_manual ."'/>\n<br>". install_update_manual ."\n</td></td></table></a>";

						$sync_name = get_sync_name($server_xml);
						$sync_list = @file("modules/gamemanager/rsync.list", FILE_IGNORE_NEW_LINES);
						if ( in_array($sync_name, $sync_list) OR ($master_server_home_id != FALSE and $master_server_home_id != $server_home['home_id']) )
						{
							$manager .= "<a href='?m=gamemanager&amp;p=rsync_install&amp;home_id=".$server_home['home_id'].
										"&amp;mod_id=".$server_home['mod_id']."&amp;update=update'>\n".
										"<table align='left' class='monitorbutton' ><tr><td align='middle' >".
										"<img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/rsync.png") . "' title='".
										 rsync_install ."'/>\n<br />". rsync_install ."\n</td></td></table></a>";
						}
					}
				}
			}

			if( $isAdmin )
			{
				if ( ( $server_xml->control_protocol and preg_match("/^(rcon|lcon|rcon2)$/" ,$server_xml->control_protocol) ) OR 
					 ( $server_xml->gameq_query_name and $server_xml->gameq_query_name == 'minecraft' ) )
				{
					$manager .= "<form name='rcon_preset".$server_home['home_id']."' action='home.php?m=gamemanager&amp;p=rcon_presets&amp;home_id=".
								 $server_home['home_id']."&amp;mod_id=".$server_home['mod_id']."' method='POST'>\n".
								 "<table align='left' class='monitorbutton' >\n".
								 "<tr>\n".
								 "<td align='middle' onclick='document.rcon_preset".$server_home['home_id'].
								 ".submit()' ><img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/rcon_preset.png") . "' /><br /><span style='font-weight:bold;'>".
								  rcon_presets .
								 "</span></td>\n".
								 "</tr>\n".
								 "</table>\n".
								 "</form>";
				}
			}
			
			$mod = $server_home['mod_key'];
			// If query name does not exist use mod key instead.
			if ($server_xml->protocol == "gameq")
				$query_name = $server_xml->gameq_query_name;
			elseif ($server_xml->protocol == "lgsl")
				$query_name = $server_xml->lgsl_query_name;
			else
				$query_name = $mod;
			
			//----------+ getting the lgsl image icon
			$icon_paths = array("images/icons/$mod.png",
								"images/icons/$query_name.png",
								"protocol/lgsl/other/icon_unknown.gif");

			$icon_path = get_first_existing_file($icon_paths);

			//Properties for all servers
			if(isset($post_home_id) && $post_home_id == $server_home['home_id'] OR isset($_GET['home_id']) && $_GET['home_id'] == $server_home['home_id'] )
				$trclass = " expandme";

			$groupusers = $db->getGroupUsersByHomeId($server_home['home_id']);
			$groupsus = "";
			if($groupusers)
			{
				foreach($groupusers as $groupu)
				{
					if($groupu['user_id'] == $server_home['user_id_main'])
						continue;
					$groupsus .= $groupu['users_login']."<br>";
				}
			}
			$groupsus = $groupsus != "" ? $groupsus = "<b>". group_users ."</b><br>".$groupsus : "";

			$owners = $db->getUsersByHomeId($server_home['home_id']);
			$other_owners = "";
			if($owners)
			{
				foreach($owners as $owner)
				{
					if($owner['user_id'] == $server_home['user_id_main'])
						continue;
					$other_owners .= $owner['users_login'].'<br>';
				}
			}
			$other_owners = $other_owners != "" ? $other_owners = "<b>". assigned_to ."</b><br>".$other_owners : "";

			$view_log = "<a href='?m=gamemanager&amp;p=log&amp;home_id-mod_id-ip-port=".$server_home['home_id']."-".
						$server_home['mod_id']."-".$server_home['ip']."-".$server_home['port']."'>\n".
						"<table align='left' class='monitorbutton' ><tr><td align='middle' >".
						"<img style='border:0;height:40px;vertical-align:middle;' src='" . check_theme_image("images/log.png") . "' title='".
						 view_log ."'/>\n<br>". view_log ."\n</td></tr></table></a>";

			$btns = $view_log.
					@$ftp.
					@$lite_fm.
					@$addonsmanager;
			//End

			$remote = new OGPRemoteLibrary($server_home['agent_ip'], $server_home['agent_port'], $server_home['encryption_key'], $server_home['timeout']);
			$host_stat = $remote->status_chk();

			if( $host_stat === 1)
			{
				if ( $server_home['use_nat'] == 1 )
					$query_ip = $server_home['agent_ip'];
				else
					$query_ip = $server_home['ip'];

				$address = $query_ip . ":" . $server_home['port'];
				$screen_running = $remote->is_screen_running(OGP_SCREEN_TYPE_HOME,$server_home['home_id']) === 1;
				$update_in_progress = $remote->is_screen_running(OGP_SCREEN_TYPE_UPDATE,$server_home['home_id']) === 1;
				if($screen_running)
				{
					// Check if the screen running the server is running.
					$status = "online";
					$order=1;
					if ($server_xml->protocol == "lgsl")
					{
						$get_q_and_s = lgsl_port_conversion($query_name, $server_home['port'], "", "");
						//Connection port
						$c_port = $get_q_and_s['0'];
						//query port
						$q_port = $get_q_and_s['1'];
						//software port
						$s_port = $get_q_and_s['2'];
						$address = "<a href='" . lgsl_software_link($query_name, $query_ip, $c_port, $q_port, $s_port) . "'>".$query_ip.":".$server_home['port']."</a>";
					}
					if ($server_xml->protocol == "teamspeak3")
						$address = "<a href='ts3server://" . $query_ip . ":" . $server_home['port'] . "'>".$query_ip.":".$server_home['port']."</a>";
					if($server_xml->protocol == "gameq" and $server_xml->installer == 'steamcmd')
						$address = "<a href='steam://connect/" . $query_ip . ":" . $server_home['port'] . "'>" . $query_ip . ":" . $server_home['port'] . "</a>";
					$pos = $refresh->add("home.php?m=gamemanager&p=ref_servermonitor&type=cleared&home_id=". $server_home['home_id'] . "&mod_id=". $server_home['mod_id'] . "&ip=" . $server_home['ip'] . "&port=" . $server_home['port']);
					if ($server_xml->protocol == "teamspeak3")
					{
						require('protocol/TeamSpeak3/functions.php');
					}
					$startup_file_exists = $remote->rfile_exists( "startups/".$server_home['ip']."-".$server_home['port'] ) === 1;
					if( isset($server_home['ip']) and isset($server_home['mod_id']) and ($server_xml->protocol != "teamspeak3" or ($startup_file_exists and $server_xml->protocol == "teamspeak3")) )
					{
						$ctrlChkBoxes .= '<div id="server_icon" class="action-stop'.$server_home['home_id'].'" ><div>'.
										 '<input id="action-stop" class="action-stop'.$server_home['home_id'].'" name="action-'.$server_home['home_id'].'" value="stop-'.
										 $server_home['home_id'].'-'.$server_home['mod_id'].'-'.$server_home['ip'].'-'.$server_home['port'].
										 '" type="radio"><img style="border:0;height:15px;" src="'  . check_theme_image("images/stop.png") . '"/></div><div>&nbsp;'.
										  stop_server .'</div></div><div id="server_icon" class="action-restart'.$server_home['home_id'].'" ><div>'.
										 '<input id="action-restart" class="action-restart'.$server_home['home_id'].'" name="action-'.$server_home['home_id'].'" value="restart-'.
										 $server_home['home_id'].'-'.$server_home['mod_id'].'-'.$server_home['ip'].'-'.$server_home['port'].
										 '" type="radio"><img style="border:0;height:15px;" src="' . check_theme_image("images/restart.png") . '"/></div><div>&nbsp;'.
										  restart_server .'</div></div>';
					}
					$stats_servers_online++;
				}
				else
				{
					$status = "offline";
					if ($server_home['last_param'] != "" and isset($server_home['ip']) and isset($server_home['mod_id']))
					{
						if($update_in_progress)
							$ctrlChkBoxes .= '<div id="server_icon" class="action-start'.$server_home['home_id'].'" >&nbsp;'. update_in_progress .'</div>';
						else
							$ctrlChkBoxes .= '<div id="server_icon" class="action-start'.$server_home['home_id'].'" >
											 <div>
											 <input id="action-start" class="action-start'.$server_home['home_id'].'" name="action-'.$server_home['home_id'].'" value="start-'.
											 $server_home['home_id'].'-'.$server_home['mod_id'].'-'.$server_home['ip'].'-'.$server_home['port'].
											 '" type="radio"><img style="border:0;height:15px;" src="' . check_theme_image("images/start.png") . '"/></div><div>&nbsp;'.
											  start_server .'</div></div>';
					}
					$order = 3;
					if(isset($server_home['mod_id']))
					{
						ob_start();
						require('modules/gamemanager/mini_start.php');
						$ministart = ob_get_contents();
						ob_end_clean();
					}
					if($update_in_progress)
						$offlineT = '<div id="server_icon" class="action-start'.$server_home['home_id'].'" >&nbsp;'. update_in_progress .'</div>';
					else
						$offlineT = $ministart;
				}
			}
			else{
				$status = "offline";
				$order = 3;
				$address = "<span style='color:darkred;font-weight:bold;'>Agent Offline</span>";
			}
			$user = $db->getUserById($server_home['user_id_main']);

			// Template
			@$first = "<tr class='maintr$trclass'>";
				$first .= "<td class='collapsible' data-status='$status' data-pos='$pos'><span class='hidden'>$order</span><a></a>" . "<img src='" . check_theme_image("images/$status.png") . "' />" . "</td>";
				$first .= "<td>" . "<span class='hidden'>$mod</span><img src='$icon_path' />" . "</td>";
				$first .= "<td class='collapsible' data-status='$status' data-pos='$pos'><a></a><b>" . htmlentities($server_home['home_name']) . "</b>$mod_name</td>";
				$first .= "<td>" . $address . "</td>";
				$first .= "<td class='owner' >" . $user['users_login'] . "</td>";
				$first .= "<td style='width:328px;padding:0px;'>$ctrlChkBoxes</td>";
			$first .= "</tr>";

			$second = "<tr class='expand-child'>";
				@$second .= "<td colspan='4'>" . $refresh->getdiv($pos,"width:100%;") . "$offlineT</td>";
				$second .= "<td class='owner' >$other_owners$groupsus</td>";
				if( $server_xml->protocol != "teamspeak3" OR ($startup_file_exists and $server_xml->protocol == "teamspeak3") OR ($status == "offline" and $server_xml->protocol == "teamspeak3") )
					@$second .= "<td class='operations' >$btns$manager<br>$mysql<br>$get_size<br>$ts3opt</td>";
				else
					$second .= "<td class='operations' >$ts3opt</td>";
			$second .= "</tr>";
			//Echo them all
			echo "$first$second";
		}
	}
	echo "</tbody>";

	echo "<tfoot style='border:1px solid grey;'>
			<tr>
			  <td colspan='6' >
				<div class='bloc' >
				<img src='" . check_theme_image("images/magnifglass.png") . "' /> ". statistics .": $stats_servers_online/$stats_servers ". servers ."\n</div>
				<div class='right bloc' >
				  <label>". execute_selected_server_operations ."</label>
				  <input id='execute_operations' type='submit' value='". execute_operations ."' >\n
				</div>
			  </td>
			</tr>
		  </tfoot>";

	echo "</table>";
	echo "<div id=translation data-title='". upload_map_image .
		 "' data-upload_button='". upload_image .
		 "' data-bad_file='". jpg_gif_png_less_than_1mb .
		 "' data-upload_failure='". check_dev_console .
		 "' ></div>\n";
	?>
	<script type="text/javascript">
	<?php echo $refresh->build(isset($settings['query_cache_life']) ? $settings['query_cache_life'] * 2000 : 60000); ?>
	</script>
	<?php
}
?>
