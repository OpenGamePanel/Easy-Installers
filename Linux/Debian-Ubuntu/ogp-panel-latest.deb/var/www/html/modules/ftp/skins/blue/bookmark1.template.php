<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/bookmark1.template.php begin -->
<?php 	echo __("Add this link to your bookmarks:"); ?>
<br /><a href="<?php echo $url; ?>"><?php echo $text; ?></a><br />
<?php echo __("Note: when you will use this bookmark, a popup window will ask you for your username and password."); ?><br />
<!-- Template /skins/blue/bookmark1.template.php end -->
