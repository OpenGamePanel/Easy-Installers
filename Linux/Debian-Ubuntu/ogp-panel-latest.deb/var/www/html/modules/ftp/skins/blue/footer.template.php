<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/footer.php begin -->
<!-- Template /skins/blue/footer.php end -->
