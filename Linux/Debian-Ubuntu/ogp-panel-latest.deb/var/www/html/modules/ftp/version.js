var latest_stable_build = 45;
var latest_stable_version = '0.98';
var latest_stable_url = 'http://www.net2ftp.com/download/net2ftp_v0.98.zip';

var latest_beta_build = 45;
var latest_beta_version = '0.98';
var latest_beta_url = 'http://www.net2ftp.com/download/net2ftp_v0.98.zip';
