<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/india/google_login.template.php begin -->
<?php if ($net2ftp_settings["show_google_ads"] == "yes") { ?>
<script type="text/javascript"><!--
google_ad_client = "pub-8420366685399799";
google_ad_width = 120;
google_ad_height = 240;
google_ad_format = "120x240_as";
google_ad_type = "text_image";
google_ad_channel ="9294235009";
google_color_border = "E5E5E5";
google_color_bg = "FFFFFF";
google_color_link = "0000FF";
google_color_text = "000000";
google_color_url = "008000";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } // end if ?>
<!-- Template /skins/india/google_login.template.php end -->
