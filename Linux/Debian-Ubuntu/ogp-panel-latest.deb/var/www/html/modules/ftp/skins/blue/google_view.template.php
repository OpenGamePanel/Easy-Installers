<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/google_ad.template.php begin -->
<?php if ($net2ftp_settings["show_google_ads"] == "yes") { ?>
<script type="text/javascript"><!--
google_ad_client = "pub-8420366685399799";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as_rimg";
google_cpa_choice = "CAAQkJOlgwIaCApbJOofoGPvKIjLynM";
google_ad_channel = "2844204813";
//--></script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } // end if ?>
<!-- Template /skins/blue/google_ad.template.php end -->
