<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/advanced_parsing.template.php begin -->
<?php	for ($i=0; $i<sizeof($net2ftp_output["advanced_parsing"]); $i++) {
		echo $net2ftp_output["advanced_parsing"][$i] . "\n";
	} // end for ?>
<!-- Template /skins/blue/advanced_parsing.template.php end -->
