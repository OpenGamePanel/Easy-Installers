$(function() {
$( 'input,textarea' ).tooltip();
});