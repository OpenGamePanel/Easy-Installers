%Cfg::Preferences = (
	screen_log_local => '1',
	delete_logs_after => '30',
	ogp_manages_ftp => '1',
	ftp_method => 'PureFTPd',
	ogp_autorestart_server => '1',
);
