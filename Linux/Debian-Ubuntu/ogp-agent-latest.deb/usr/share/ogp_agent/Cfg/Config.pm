%Cfg::Config = (
    logfile => '/usr/share/ogp_agent/ogp_agent.log',
    listen_port  => '12679',
    listen_ip => '0.0.0.0',
    version => 'v3332',
    key => 'changeme',
    steam_license => 'Accept',
    sudo_password => 'changeme',
);
